RESHock website
1. Open index.html to preview.
2. Open admin.html to add products and change prices on this device.
3. To put it online, upload these files to a static website host.
Note: the Update page uses browser localStorage, so changes made on one phone/browser are not automatically shared with other devices. A real multi-device admin system needs a database/backend.
